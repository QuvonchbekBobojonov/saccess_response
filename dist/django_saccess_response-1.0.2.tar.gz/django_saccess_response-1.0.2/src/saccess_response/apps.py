from django.apps import AppConfig


class SaccessResponseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'saccess_response'
